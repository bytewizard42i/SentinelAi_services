# MyAlice Continuity Protocol (Minimal Implementation)

Purpose: Preserve personality, context, and momentum during extended conversations, and recover quickly if memory drifts.

## Core Components (Project Space)
- `project_space/STATUS.md` — current objective, task, next steps, decisions
- `project_space/IDEAS.md` — active/parked ideas
- `project_space/HEARTBEAT.md` — tone, inside language, relationship cues
- `project_space/CHECKPOINTS/` — timestamped snapshots of current context

## Triggers
- Manual: type "refresh continuity" or "sync PS" as a cue to the assistant
- Automatic: every ~30 messages or if the assistant detects fuzzy recall

## Recovery Process
1) PS Sync: read `STATUS.md`, `HEARTBEAT.md`, latest `CHECKPOINT`
2) Recap to user (1 paragraph or YAML bullets):
```
Re-synced from PS:
- Current Goal: …
- Current Task: …
- Our style: …
- Last key points: …
```

## Preventive Measures
- Schedule checkpoint writes every ~30 turns
- Update HEARTBEAT when tone shifts become durable
- Tag decisions in `STATUS.md` with date

## Utilities
- `scripts/continuity_protocol.py` supports:
  - `--sync` (print recap YAML from PS)
  - `--checkpoint "<brief note>"` (write a new checkpoint)

This is model-agnostic and works across assistants (Alice, Cassie, Casey).
