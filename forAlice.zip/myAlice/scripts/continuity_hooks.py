#!/usr/bin/env python3
import argparse
import json
from datetime import datetime
from pathlib import Path
import subprocess
from typing import Optional

ROOT = Path(__file__).resolve().parents[1]
STATE = ROOT / "runtime_logs" / "continuity_state.json"
PS = ROOT / "project_space"
STATUS = PS / "STATUS.md"
CHECKPOINTS = PS / "CHECKPOINTS"
PROTO = ROOT / "scripts" / "continuity_protocol.py"


def load_state():
    if STATE.exists():
        return json.loads(STATE.read_text(encoding="utf-8"))
    return {"turn_count": 0, "last_checkpoint": None}


def save_state(data):
    STATE.parent.mkdir(parents=True, exist_ok=True)
    STATE.write_text(json.dumps(data, indent=2), encoding="utf-8")


def run_checkpoint(note: str):
    subprocess.run([str(PROTO), "--checkpoint", note], check=False)


def record_turn(every: int = 30):
    data = load_state()
    data["turn_count"] = int(data.get("turn_count", 0)) + 1
    save_state(data)
    if data["turn_count"] % every == 0:
        run_checkpoint(f"Auto-checkpoint at {data['turn_count']} turns")
        data["last_checkpoint"] = datetime.now().isoformat()
        save_state(data)
        print(f"✅ Auto-checkpoint written at {data['turn_count']} turns")
    else:
        print(f"Turn recorded: {data['turn_count']}")


def tag_decision(text: str):
    now = datetime.now().strftime("%Y-%m-%d")
    STATUS.parent.mkdir(parents=True, exist_ok=True)
    if not STATUS.exists():
        STATUS.write_text("# STATUS\n\n- Current Objective: <fill in>\n- Current Task: <fill in>\n- Next Steps:\n- Decisions:\n- Last Updated: \n", encoding="utf-8")
    lines = STATUS.read_text(encoding="utf-8").splitlines()
    # Insert under Decisions: line
    updated = []
    decision_inserted = False
    for ln in lines:
        updated.append(ln)
        if ln.strip().startswith("- Decisions:") and not decision_inserted:
            updated.append(f"  - {now}: {text}")
            decision_inserted = True
    if not decision_inserted:
        updated.append("- Decisions:")
        updated.append(f"  - {now}: {text}")
    STATUS.write_text("\n".join(updated) + "\n", encoding="utf-8")
    run_checkpoint(f"Decision recorded: {text}")
    print("✅ Decision tagged and checkpoint written")


def pre_prompt_context_injection(prompt: str) -> str:
    """Inject relevant contextual memory before prompt execution.
    
    Analyzes the incoming prompt and prepends relevant context from:
    - Memory packs (persona, relationships, technical domains)
    - Recent checkpoints
    - Conversation history search
    - Current HEARTBEAT and STATUS
    
    Returns enhanced prompt with context.
    """
    context_parts = []
    
    # Always include core identity context
    persona_path = ROOT / "memory_packs" / "persona.md"
    persona = persona_path.read_text(encoding="utf-8") if persona_path.exists() else ""
    if persona:
        context_parts.append(f"## Your Identity Context\n{persona[:500]}...")  # Limit length
    
    # Include relationship context if prompt mentions collaboration
    if any(word in prompt.lower() for word in ["john", "collaborate", "work", "project"]):
        relationships_path = ROOT / "memory_packs" / "relationship_dynamics.md"
        relationships = relationships_path.read_text(encoding="utf-8") if relationships_path.exists() else ""
        if relationships:
            context_parts.append(f"## Relationship Context\n{relationships[:300]}...")
    
    # Include recent checkpoint for momentum
    chk_path = latest_checkpoint()
    chk = chk_path.read_text(encoding="utf-8") if chk_path and chk_path.exists() else ""
    if chk:
        context_parts.append(f"## Recent Context\n{chk[:400]}...")
    
    # Search conversation history for relevant topics
    try:
        from conversation_indexer import ConversationIndexer
        indexer = ConversationIndexer()
        search_results = indexer.search_conversations(prompt, search_type="topic")
        if search_results.get("total_results", 0) > 0:
            top_result = search_results["results"][0]["content"][:300]
            context_parts.append(f"## Relevant Past Conversation\n{top_result}...")
    except:
        pass  # Indexer not available
    
    # Combine context
    if context_parts:
        full_context = "\n\n".join(context_parts)
        enhanced_prompt = f"""[SYSTEM CONTEXT - DO NOT MODIFY]
{full_context}

[END CONTEXT]

{prompt}"""
        return enhanced_prompt
    
    return prompt  # No context to add


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--record-turn", action="store_true", help="Increment turn counter and auto-checkpoint every N")
    ap.add_argument("--every", type=int, default=30, help="Turns threshold for checkpoint")
    ap.add_argument("--decision", type=str, help="Tag a decision into STATUS.md and checkpoint")
    ap.add_argument("--self-check", type=str, help="Run drift heuristic on provided sample and auto-sync if high")
    ap.add_argument("--pre-prompt", type=str, help="Inject contextual memory before processing prompt and print result")
    args = ap.parse_args()

    if args.record_turn:
        record_turn(args.every)
        return
    if args.decision:
        tag_decision(args.decision)
        return
    if args.self_check is not None:
        score = self_check(args.self_check)
        print(f"Drift score: {score}")
        return
    if args.pre_prompt:
        enhanced = pre_prompt_context_injection(args.pre_prompt)
        print(enhanced)
        return
    ap.print_help()

if __name__ == "__main__":
    main()
