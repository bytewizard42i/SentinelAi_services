#!/bin/bash

# Alice Memory - Daily Automated Backup Script
# Creates git tags with timestamps for memory state snapshots

set -e

# Configuration
REPO_DIR="/home/js/utils_myAlice"
DATE_FORMAT=$(date +"%Y-%m-%d_%H-%M-%S")
TAG_PREFIX="memory-snapshot"
LOG_FILE="$REPO_DIR/runtime_logs/backup.log"

# Ensure we're in the correct directory
cd "$REPO_DIR"

# Create runtime_logs directory if it doesn't exist
mkdir -p runtime_logs

# Log function
log() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" | tee -a "$LOG_FILE"
}

log "Starting daily memory backup process..."

# Check if we're in a git repository
if [ ! -d ".git" ]; then
    log "ERROR: Not in a git repository"
    exit 1
fi

# Check for uncommitted changes
if ! git diff-index --quiet HEAD --; then
    log "WARNING: Uncommitted changes detected. Committing before backup..."
    git add .
    git commit -m "🔄 Auto-commit before daily backup - $(date '+%Y-%m-%d %H:%M:%S')"
fi

# Create memory snapshot tag
TAG_NAME="${TAG_PREFIX}-${DATE_FORMAT}"
COMMIT_HASH=$(git rev-parse HEAD)

# Create annotated tag with metadata
git tag -a "$TAG_NAME" -m "Daily Memory Snapshot - $DATE_FORMAT

Memory State Metadata:
- Timestamp: $(date '+%Y-%m-%d %H:%M:%S %Z')
- Commit: $COMMIT_HASH
- Memory Packs: $(find memory_packs -name "*.md" -o -name "*.jsonl" | wc -l) files
- Chat History: $(wc -l < Ai-chat.md) lines
- Runtime Logs: $(find runtime_logs -name "*.log" 2>/dev/null | wc -l) files

Automated backup via daily_backup.sh"

# Push tag to remote
if git push origin "$TAG_NAME" 2>/dev/null; then
    log "SUCCESS: Memory snapshot '$TAG_NAME' created and pushed to remote"
else
    log "WARNING: Tag created locally but failed to push to remote"
fi

# Cleanup old tags (keep last 30 days)
log "Cleaning up old backup tags (keeping last 30)..."
git tag -l "${TAG_PREFIX}-*" | sort -r | tail -n +31 | while read -r old_tag; do
    if [ -n "$old_tag" ]; then
        log "Removing old tag: $old_tag"
        git tag -d "$old_tag" 2>/dev/null || true
        git push origin ":refs/tags/$old_tag" 2>/dev/null || true
    fi
done

# Generate backup summary
TOTAL_TAGS=$(git tag -l "${TAG_PREFIX}-*" | wc -l)
log "Backup complete. Total memory snapshots: $TOTAL_TAGS"

# Update backup statistics
echo "{
  \"last_backup\": \"$(date -Iseconds)\",
  \"backup_tag\": \"$TAG_NAME\",
  \"commit_hash\": \"$COMMIT_HASH\",
  \"total_snapshots\": $TOTAL_TAGS,
  \"memory_files\": $(find memory_packs -name "*.md" -o -name "*.jsonl" | wc -l),
  \"chat_lines\": $(wc -l < Ai-chat.md)
}" > runtime_logs/backup_stats.json

log "Daily backup process completed successfully"
