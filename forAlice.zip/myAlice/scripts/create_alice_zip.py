#!/usr/bin/env python3

"""
Enhanced Alice Memory Pack Creator
Creates timestamped zip files with unique thumbnails for Alice
"""

import os
import sys
import zipfile
import hashlib
from datetime import datetime
from pathlib import Path
import json
import subprocess
from PIL import Image, ImageDraw, ImageFont
import io

class AliceZipCreator:
    def __init__(self, repo_path):
        self.repo_path = Path(repo_path)
        self.timestamp = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
        self.date_only = datetime.now().strftime("%Y-%m-%d")
        
    def generate_unique_thumbnail(self, zip_path, content_hash):
        """Generate a unique thumbnail based on content hash and timestamp"""
        # Create a 256x256 thumbnail
        img = Image.new('RGB', (256, 256), color='#1a1a2e')
        draw = ImageDraw.Draw(img)
        
        # Use content hash to generate unique colors and patterns
        hash_int = int(content_hash[:8], 16)
        
        # Generate colors from hash
        primary_color = (
            (hash_int >> 16) & 0xFF,
            (hash_int >> 8) & 0xFF,
            hash_int & 0xFF
        )
        
        # Create gradient background
        for y in range(256):
            gradient_color = tuple(
                int(c * (1 - y/256) + 0x2e * (y/256)) for c in primary_color
            )
            draw.line([(0, y), (256, y)], fill=gradient_color)
        
        # Draw unique pattern based on hash
        pattern_seed = hash_int % 8
        if pattern_seed == 0:
            # Circles
            for i in range(5):
                x = (hash_int >> (i*4)) % 200 + 28
                y = (hash_int >> (i*4+2)) % 200 + 28
                r = 20 + (hash_int >> (i*2)) % 30
                draw.ellipse([x-r, y-r, x+r, y+r], outline='white', width=2)
        elif pattern_seed == 1:
            # Lines
            for i in range(8):
                x1 = (hash_int >> (i*3)) % 256
                y1 = (hash_int >> (i*3+1)) % 256
                x2 = (hash_int >> (i*3+2)) % 256
                y2 = (hash_int >> (i*3+3)) % 256
                draw.line([(x1, y1), (x2, y2)], fill='white', width=2)
        else:
            # Rectangles
            for i in range(6):
                x = (hash_int >> (i*4)) % 200 + 28
                y = (hash_int >> (i*4+2)) % 200 + 28
                w = 30 + (hash_int >> (i*2)) % 40
                h = 30 + (hash_int >> (i*2+1)) % 40
                draw.rectangle([x, y, x+w, y+h], outline='white', width=2)
        
        # Add Alice icon/text
        try:
            font = ImageFont.load_default()
        except:
            font = None
            
        # Add timestamp and Alice label
        draw.text((10, 10), "ALICE", fill='white', font=font)
        draw.text((10, 230), self.timestamp, fill='white', font=font)
        
        # Add content indicator
        draw.text((10, 210), f"Hash: {content_hash[:8]}", fill='white', font=font)
        
        # Save thumbnail
        thumbnail_path = zip_path.with_suffix('.png')
        img.save(thumbnail_path)
        print(f"✅ Generated unique thumbnail: {thumbnail_path.name}")
        return thumbnail_path
        
    def calculate_content_hash(self, files_to_zip):
        """Calculate hash of all content to be zipped"""
        hasher = hashlib.sha256()
        
        for file_path in sorted(files_to_zip):
            if file_path.is_file():
                with open(file_path, 'rb') as f:
                    hasher.update(f.read())
            hasher.update(str(file_path).encode())
            
        return hasher.hexdigest()
        
    def create_zip(self):
        """Create enhanced zip file with timestamp and thumbnail"""
        # Define zip filename with enhanced timestamp
        zip_filename = f"Alice_Memory_Pack_{self.timestamp}.zip"
        zip_path = self.repo_path / zip_filename
        
        # Files to include in the zip
        files_to_include = [
            "ALICE_CASSIE_CONVERSATIONS.md",
            "ALICE_CASSIE_SYNC.md",
            "Ai-chat.md",
            "project_space/",
            "memory_packs/",
            "scripts/",
            "runtime_logs/"
        ]
        
        files_to_zip = []
        for item in files_to_include:
            item_path = self.repo_path / item
            if item_path.exists():
                if item_path.is_file():
                    files_to_zip.append(item_path)
                elif item_path.is_dir():
                    files_to_zip.extend(item_path.rglob('*'))
        
        # Calculate content hash for unique thumbnail
        content_hash = self.calculate_content_hash(files_to_zip)
        
        # Create the zip file
        with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
            for file_path in files_to_zip:
                if file_path.is_file():
                    arcname = file_path.relative_to(self.repo_path)
                    zipf.write(file_path, arcname)
        
        # Generate unique thumbnail
        thumbnail_path = self.generate_unique_thumbnail(zip_path, content_hash)
        
        # Create metadata file
        metadata = {
            "created": datetime.now().isoformat(),
            "timestamp": self.timestamp,
            "content_hash": content_hash,
            "file_count": len([f for f in files_to_zip if f.is_file()]),
            "zip_size": zip_path.stat().st_size,
            "thumbnail": thumbnail_path.name
        }
        
        metadata_path = zip_path.with_suffix('.json')
        with open(metadata_path, 'w') as f:
            json.dump(metadata, f, indent=2)
        
        print(f"🎉 Created enhanced Alice memory pack:")
        print(f"   📦 Zip: {zip_filename}")
        print(f"   🖼️  Thumbnail: {thumbnail_path.name}")
        print(f"   📋 Metadata: {metadata_path.name}")
        print(f"   📊 Files: {metadata['file_count']}")
        print(f"   💾 Size: {metadata['zip_size']:,} bytes")
        print(f"   🔑 Hash: {content_hash[:16]}...")
        
        return zip_path, thumbnail_path, metadata_path

def main():
    repo_path = Path(__file__).parent.parent
    creator = AliceZipCreator(repo_path)
    
    try:
        zip_path, thumbnail_path, metadata_path = creator.create_zip()
        print("\n✅ Enhanced Alice memory pack created successfully!")
        
        # Clean up old zip files (keep last 5)
        old_zips = sorted(repo_path.glob("Alice_Memory_Pack_*.zip"))
        if len(old_zips) > 5:
            for old_zip in old_zips[:-5]:
                old_zip.unlink(missing_ok=True)
                # Also remove associated files
                old_zip.with_suffix('.png').unlink(missing_ok=True)
                old_zip.with_suffix('.json').unlink(missing_ok=True)
                print(f"🗑️  Cleaned up old file: {old_zip.name}")
                
    except Exception as e:
        print(f"❌ Error creating Alice memory pack: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()
