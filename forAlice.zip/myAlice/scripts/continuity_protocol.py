#!/usr/bin/env python3
import argparse
import datetime as dt
from pathlib import Path
import textwrap

ROOT = Path(__file__).resolve().parents[1]
PS = ROOT / "project_space"
STATUS = PS / "STATUS.md"
HEARTBEAT = PS / "HEARTBEAT.md"
CHECKPOINTS = PS / "CHECKPOINTS"


def now_stamp():
    return dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S %Z")


def ensure_dirs():
    CHECKPOINTS.mkdir(parents=True, exist_ok=True)


def read(path: Path) -> str:
    return path.read_text(encoding="utf-8") if path.exists() else ""


def latest_checkpoint() -> Path | None:
    if not CHECKPOINTS.exists():
        return None
    files = sorted(CHECKPOINTS.glob("checkpoint-*.md"))
    return files[-1] if files else None


def recap_yaml() -> str:
    status = read(STATUS)
    hb = read(HEARTBEAT)
    chk_path = latest_checkpoint()
    chk = read(chk_path) if chk_path else ""

    # helpers to extract structured cues from simple markdown
    def extract_after_prefix(lines: list[str], prefix: str, default: str = "n/a") -> str:
        for ln in lines:
            s = ln.strip()
            if s.startswith(prefix):
                return s[len(prefix):].strip() or default
        return default

    def extract_first_bullet_after_heading(lines: list[str], heading: str, default: str = "n/a") -> str:
        in_section = False
        for ln in lines:
            s = ln.strip()
            if s.lower().startswith(heading.lower()):
                in_section = True
                continue
            if in_section:
                if s.startswith("## ") or s.startswith("# "):
                    break
                if s.startswith("- "):
                    return s[2:].strip()
        return default

    status_lines = status.splitlines()
    hb_lines = hb.splitlines()
    chk_lines = chk.splitlines()

    current_goal = extract_after_prefix(status_lines, "- Current Objective:")
    current_task = extract_after_prefix(status_lines, "- Current Task:")
    style_cue = extract_first_bullet_after_heading(hb_lines, "## Style Cues")

    # For checkpoint, try to grab the first bullet under "Current task/context:" block
    def extract_checkpoint_keypoint(lines: list[str]) -> str:
        in_block = False
        for ln in lines:
            s = ln.strip()
            if s.lower().startswith("current task/context:"):
                in_block = True
                continue
            if in_block:
                if s.startswith("- "):
                    return s[2:].strip()
                if s.startswith("# ") or s.startswith("## "):
                    break
        # fallback: first non-header non-empty line
        for ln in lines:
            s = ln.strip()
            if s and not s.startswith("#"):
                return s
        return "n/a"

    last_key_points = extract_checkpoint_keypoint(chk_lines) if chk_lines else "n/a"

    return textwrap.dedent(f"""
    Re-synced from PS:
    - Current Goal: {current_goal}
    - Current Task: {current_task}
    - Our style: {style_cue}
    - Last key points: {last_key_points}
    """).strip()


def write_checkpoint(note: str):
    ensure_dirs()
    ts = dt.datetime.now().strftime("%Y%m%d-%H%M%S")
    path = CHECKPOINTS / f"checkpoint-{ts}.md"
    content = textwrap.dedent(f"""
    # Checkpoint {ts}
    
    Current task/context:
    - {note}
    
    References:
    - STATUS.md summary
    - HEARTBEAT.md cues
    """).strip() + "\n"
    path.write_text(content, encoding="utf-8")
    print(f"Wrote {path}")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--sync", action="store_true", help="Print recap YAML from PS")
    ap.add_argument("--checkpoint", type=str, help="Write a checkpoint with brief note")
    args = ap.parse_args()

    if args.sync:
        print(recap_yaml())
        return
    if args.checkpoint:
        write_checkpoint(args.checkpoint)
        return
    ap.print_help()


if __name__ == "__main__":
    main()
