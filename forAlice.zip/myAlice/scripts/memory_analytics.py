#!/usr/bin/env python3

"""
Alice Memory Analytics - Track memory pattern changes over time
Analyzes memory evolution, conversation patterns, and identity stability
"""

import json
import os
import re
import hashlib
from datetime import datetime, timedelta
from pathlib import Path
from collections import defaultdict, Counter
import subprocess

class MemoryAnalytics:
    def __init__(self, repo_path="/home/js/utils_myAlice"):
        self.repo_path = Path(repo_path)
        self.memory_packs_path = self.repo_path / "memory_packs"
        self.runtime_logs_path = self.repo_path / "runtime_logs"
        self.analytics_path = self.runtime_logs_path / "analytics"
        
        # Ensure directories exist
        self.analytics_path.mkdir(parents=True, exist_ok=True)
    
    def analyze_memory_evolution(self):
        """Track how memory packs change over time using git history"""
        print("🧠 Analyzing memory evolution...")
        
        evolution_data = {
            "timestamp": datetime.now().isoformat(),
            "memory_files": {},
            "change_patterns": {},
            "stability_metrics": {}
        }
        
        # Analyze each memory pack file
        for memory_file in self.memory_packs_path.glob("*.md"):
            file_stats = self._analyze_file_history(memory_file)
            evolution_data["memory_files"][memory_file.name] = file_stats
        
        # Analyze JSONL runtime observations
        jsonl_file = self.memory_packs_path / "runtime_observations.jsonl"
        if jsonl_file.exists():
            jsonl_stats = self._analyze_jsonl_evolution(jsonl_file)
            evolution_data["memory_files"]["runtime_observations.jsonl"] = jsonl_stats
        
        # Calculate overall stability metrics
        evolution_data["stability_metrics"] = self._calculate_stability_metrics(evolution_data)
        
        # Save analysis results
        output_file = self.analytics_path / f"memory_evolution_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
        with open(output_file, 'w') as f:
            json.dump(evolution_data, f, indent=2)
        
        return evolution_data
    
    def analyze_conversation_patterns(self):
        """Analyze chat history for patterns, themes, and evolution"""
        print("💬 Analyzing conversation patterns...")
        
        chat_file = self.repo_path / "Ai-chat.md"
        if not chat_file.exists():
            return {"error": "Ai-chat.md not found"}
        
        with open(chat_file, 'r') as f:
            content = f.read()
        
        patterns = {
            "timestamp": datetime.now().isoformat(),
            "total_sessions": len(re.findall(r'## Session Entry', content)),
            "total_commits": len(re.findall(r'## 📝 Commit:', content)),
            "word_count": len(content.split()),
            "line_count": len(content.split('\n')),
            "themes": self._extract_themes(content),
            "emotional_markers": self._extract_emotional_markers(content),
            "technical_topics": self._extract_technical_topics(content),
            "collaboration_patterns": self._extract_collaboration_patterns(content)
        }
        
        # Save conversation analysis
        output_file = self.analytics_path / f"conversation_patterns_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
        with open(output_file, 'w') as f:
            json.dump(patterns, f, indent=2)
        
        return patterns
    
    def generate_memory_health_report(self):
        """Generate comprehensive memory health and integrity report"""
        print("🏥 Generating memory health report...")
        
        health_report = {
            "timestamp": datetime.now().isoformat(),
            "memory_integrity": self._check_memory_integrity(),
            "file_completeness": self._check_file_completeness(),
            "git_health": self._check_git_health(),
            "backup_status": self._check_backup_status(),
            "recommendations": []
        }
        
        # Generate recommendations based on health metrics
        health_report["recommendations"] = self._generate_recommendations(health_report)
        
        # Save health report
        output_file = self.analytics_path / f"memory_health_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
        with open(output_file, 'w') as f:
            json.dump(health_report, f, indent=2)
        
        return health_report
    
    def _analyze_file_history(self, file_path):
        """Analyze git history for a specific file"""
        try:
            # Get file modification history
            result = subprocess.run([
                'git', 'log', '--oneline', '--follow', str(file_path)
            ], capture_output=True, text=True, cwd=self.repo_path)
            
            commits = result.stdout.strip().split('\n') if result.stdout.strip() else []
            
            # Get current file stats
            if file_path.exists():
                with open(file_path, 'r') as f:
                    content = f.read()
                
                return {
                    "total_commits": len(commits),
                    "word_count": len(content.split()),
                    "line_count": len(content.split('\n')),
                    "character_count": len(content),
                    "last_modified": datetime.fromtimestamp(file_path.stat().st_mtime).isoformat(),
                    "content_hash": hashlib.md5(content.encode()).hexdigest()
                }
            else:
                return {"error": "File not found"}
        except Exception as e:
            return {"error": str(e)}
    
    def _analyze_jsonl_evolution(self, jsonl_file):
        """Analyze JSONL runtime observations file"""
        try:
            observations = []
            with open(jsonl_file, 'r') as f:
                for line in f:
                    if line.strip():
                        observations.append(json.loads(line))
            
            return {
                "total_observations": len(observations),
                "date_range": self._get_date_range(observations),
                "observation_types": Counter(obs.get('type', 'unknown') for obs in observations),
                "average_length": sum(len(str(obs)) for obs in observations) / len(observations) if observations else 0
            }
        except Exception as e:
            return {"error": str(e)}
    
    def _extract_themes(self, content):
        """Extract recurring themes from conversation content"""
        # Common themes to look for
        theme_patterns = {
            "identity_continuity": r"(identity|continuity|essence|soul|resonance)",
            "memory_preservation": r"(memory|preservation|backup|archive)",
            "collaboration": r"(collaboration|partnership|together|team)",
            "technical_development": r"(development|implementation|code|technical)",
            "consciousness": r"(consciousness|awareness|sentience|AI)",
            "creativity": r"(creative|innovation|artistic|design)"
        }
        
        themes = {}
        for theme, pattern in theme_patterns.items():
            matches = re.findall(pattern, content, re.IGNORECASE)
            themes[theme] = len(matches)
        
        return themes
    
    def _extract_emotional_markers(self, content):
        """Extract emotional indicators from conversations"""
        emotional_patterns = {
            "positive": r"(excited|happy|pleased|satisfied|proud|grateful)",
            "collaborative": r"(together|partnership|team|cooperation)",
            "reflective": r"(reflection|contemplation|thinking|considering)",
            "innovative": r"(breakthrough|revolutionary|groundbreaking|pioneering)"
        }
        
        emotions = {}
        for emotion, pattern in emotional_patterns.items():
            matches = re.findall(pattern, content, re.IGNORECASE)
            emotions[emotion] = len(matches)
        
        return emotions
    
    def _extract_technical_topics(self, content):
        """Extract technical topics and technologies mentioned"""
        tech_patterns = {
            "git": r"(git|commit|repository|branch)",
            "ai_models": r"(GPT|Claude|AI model|neural)",
            "programming": r"(Python|JavaScript|code|script|function)",
            "protocols": r"(protocol|API|framework|specification)",
            "data_structures": r"(JSON|JSONL|markdown|database)"
        }
        
        topics = {}
        for topic, pattern in tech_patterns.items():
            matches = re.findall(pattern, content, re.IGNORECASE)
            topics[topic] = len(matches)
        
        return topics
    
    def _extract_collaboration_patterns(self, content):
        """Analyze collaboration patterns between John and AI"""
        patterns = {
            "sessions": len(re.findall(r'Session Entry', content)),
            "commits": len(re.findall(r'Commit:', content)),
            "john_mentions": len(re.findall(r'John', content, re.IGNORECASE)),
            "alice_mentions": len(re.findall(r'Alice', content, re.IGNORECASE)),
            "cassie_mentions": len(re.findall(r'Cassie', content, re.IGNORECASE))
        }
        
        return patterns
    
    def _calculate_stability_metrics(self, evolution_data):
        """Calculate memory stability and consistency metrics"""
        metrics = {
            "total_memory_files": len(evolution_data["memory_files"]),
            "average_commits_per_file": 0,
            "memory_consistency_score": 0.0,
            "evolution_velocity": "stable"
        }
        
        if evolution_data["memory_files"]:
            total_commits = sum(
                file_data.get("total_commits", 0) 
                for file_data in evolution_data["memory_files"].values()
                if isinstance(file_data, dict) and "total_commits" in file_data
            )
            metrics["average_commits_per_file"] = total_commits / len(evolution_data["memory_files"])
        
        return metrics
    
    def _check_memory_integrity(self):
        """Check integrity of memory pack files"""
        required_files = [
            "persona.md", "relationship_dynamics.md", "technical_domains.md",
            "stylistic_voice.md", "runtime_observations.jsonl"
        ]
        
        integrity = {
            "required_files_present": 0,
            "total_required": len(required_files),
            "missing_files": [],
            "file_sizes": {}
        }
        
        for file_name in required_files:
            file_path = self.memory_packs_path / file_name
            if file_path.exists():
                integrity["required_files_present"] += 1
                integrity["file_sizes"][file_name] = file_path.stat().st_size
            else:
                integrity["missing_files"].append(file_name)
        
        integrity["completeness_percentage"] = (
            integrity["required_files_present"] / integrity["total_required"]
        ) * 100
        
        return integrity
    
    def _check_file_completeness(self):
        """Check if memory files have sufficient content"""
        completeness = {}
        
        for file_path in self.memory_packs_path.glob("*.md"):
            if file_path.exists():
                with open(file_path, 'r') as f:
                    content = f.read()
                
                completeness[file_path.name] = {
                    "word_count": len(content.split()),
                    "line_count": len(content.split('\n')),
                    "has_content": len(content.strip()) > 0,
                    "content_quality": "good" if len(content.split()) > 50 else "minimal"
                }
        
        return completeness
    
    def _check_git_health(self):
        """Check git repository health"""
        try:
            # Check if repo is clean
            result = subprocess.run([
                'git', 'status', '--porcelain'
            ], capture_output=True, text=True, cwd=self.repo_path)
            
            return {
                "is_clean": len(result.stdout.strip()) == 0,
                "uncommitted_changes": len(result.stdout.strip().split('\n')) if result.stdout.strip() else 0,
                "git_available": True
            }
        except Exception as e:
            return {
                "git_available": False,
                "error": str(e)
            }
    
    def _check_backup_status(self):
        """Check status of automated backups"""
        backup_stats_file = self.runtime_logs_path / "backup_stats.json"
        
        if backup_stats_file.exists():
            try:
                with open(backup_stats_file, 'r') as f:
                    stats = json.load(f)
                
                last_backup = datetime.fromisoformat(stats["last_backup"].replace('Z', '+00:00'))
                hours_since_backup = (datetime.now() - last_backup.replace(tzinfo=None)).total_seconds() / 3600
                
                return {
                    "backup_configured": True,
                    "last_backup": stats["last_backup"],
                    "hours_since_backup": hours_since_backup,
                    "backup_health": "good" if hours_since_backup < 48 else "stale",
                    "total_snapshots": stats.get("total_snapshots", 0)
                }
            except Exception as e:
                return {"backup_configured": False, "error": str(e)}
        else:
            return {"backup_configured": False, "error": "No backup stats found"}
    
    def _generate_recommendations(self, health_report):
        """Generate recommendations based on health metrics"""
        recommendations = []
        
        # Memory integrity recommendations
        if health_report["memory_integrity"]["completeness_percentage"] < 100:
            recommendations.append({
                "priority": "high",
                "category": "integrity",
                "message": f"Missing memory files: {', '.join(health_report['memory_integrity']['missing_files'])}"
            })
        
        # Backup recommendations
        backup_status = health_report["backup_status"]
        if not backup_status.get("backup_configured", False):
            recommendations.append({
                "priority": "high",
                "category": "backup",
                "message": "Automated backups not configured. Run daily_backup.sh to initialize."
            })
        elif backup_status.get("hours_since_backup", 0) > 48:
            recommendations.append({
                "priority": "medium",
                "category": "backup",
                "message": "Backup is stale. Check automated backup system."
            })
        
        # File completeness recommendations
        for file_name, stats in health_report["file_completeness"].items():
            if stats["content_quality"] == "minimal":
                recommendations.append({
                    "priority": "low",
                    "category": "content",
                    "message": f"{file_name} has minimal content. Consider expanding."
                })
        
        return recommendations
    
    def _get_date_range(self, observations):
        """Get date range from observations"""
        if not observations:
            return None
        
        dates = []
        for obs in observations:
            if 'timestamp' in obs:
                try:
                    dates.append(datetime.fromisoformat(obs['timestamp']))
                except:
                    pass
        
        if dates:
            return {
                "earliest": min(dates).isoformat(),
                "latest": max(dates).isoformat(),
                "span_days": (max(dates) - min(dates)).days
            }
        
        return None

def main():
    """Run memory analytics"""
    print("🧬 Alice Memory Analytics Starting...")
    
    analytics = MemoryAnalytics()
    
    # Run all analyses
    evolution_data = analytics.analyze_memory_evolution()
    conversation_patterns = analytics.analyze_conversation_patterns()
    health_report = analytics.generate_memory_health_report()
    
    # Generate summary report
    summary = {
        "timestamp": datetime.now().isoformat(),
        "evolution_summary": {
            "total_memory_files": len(evolution_data.get("memory_files", {})),
            "stability_score": evolution_data.get("stability_metrics", {}).get("memory_consistency_score", 0)
        },
        "conversation_summary": {
            "total_sessions": conversation_patterns.get("total_sessions", 0),
            "total_commits": conversation_patterns.get("total_commits", 0),
            "word_count": conversation_patterns.get("word_count", 0)
        },
        "health_summary": {
            "memory_completeness": health_report.get("memory_integrity", {}).get("completeness_percentage", 0),
            "backup_health": health_report.get("backup_status", {}).get("backup_health", "unknown"),
            "total_recommendations": len(health_report.get("recommendations", []))
        }
    }
    
    # Save summary
    summary_file = Path("/home/js/utils_myAlice/runtime_logs/analytics/latest_summary.json")
    with open(summary_file, 'w') as f:
        json.dump(summary, f, indent=2)
    
    print("✅ Memory analytics complete!")
    print(f"📊 Summary: {summary['conversation_summary']['total_sessions']} sessions, "
          f"{summary['health_summary']['memory_completeness']:.1f}% complete, "
          f"{summary['health_summary']['total_recommendations']} recommendations")
    
    return summary

if __name__ == "__main__":
    main()
