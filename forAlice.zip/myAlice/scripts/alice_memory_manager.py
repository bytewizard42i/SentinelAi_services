#!/usr/bin/env python3

"""
Alice Memory Manager - Main control script for memory enhancements
Coordinates automated backups, analytics, and conversation indexing
"""

import sys
import subprocess
from pathlib import Path
from datetime import datetime

def run_daily_backup():
    """Run the daily backup script"""
    print("🔄 Running daily backup...")
    script_path = Path(__file__).parent / "daily_backup.sh"
    
    try:
        result = subprocess.run([str(script_path)], 
                              capture_output=True, text=True, check=True)
        print("✅ Daily backup completed successfully")
        return True
    except subprocess.CalledProcessError as e:
        print(f"❌ Backup failed: {e}")
        print(f"Output: {e.stdout}")
        print(f"Error: {e.stderr}")
        return False

def run_memory_analytics():
    """Run memory analytics"""
    print("🧠 Running memory analytics...")
    script_path = Path(__file__).parent / "memory_analytics.py"
    
    try:
        result = subprocess.run([sys.executable, str(script_path)], 
                              capture_output=True, text=True, check=True)
        print("✅ Memory analytics completed successfully")
        return True
    except subprocess.CalledProcessError as e:
        print(f"❌ Analytics failed: {e}")
        print(f"Output: {e.stdout}")
        print(f"Error: {e.stderr}")
        return False

def run_conversation_indexing():
    """Run conversation indexing"""
    print("💬 Running conversation indexing...")
    script_path = Path(__file__).parent / "conversation_indexer.py"
    
    try:
        result = subprocess.run([sys.executable, str(script_path)], 
                              capture_output=True, text=True, check=True)
        print("✅ Conversation indexing completed successfully")
        return True
    except subprocess.CalledProcessError as e:
        print(f"❌ Indexing failed: {e}")
        print(f"Output: {e.stdout}")
        print(f"Error: {e.stderr}")
        return False

def run_all_enhancements():
    """Run all memory enhancements"""
    print("🧬 Alice Memory Manager - Running All Enhancements")
    print(f"Started at: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print("=" * 60)
    
    results = {
        "backup": run_daily_backup(),
        "analytics": run_memory_analytics(),
        "indexing": run_conversation_indexing()
    }
    
    print("=" * 60)
    print("📊 Enhancement Results:")
    for enhancement, success in results.items():
        status = "✅ SUCCESS" if success else "❌ FAILED"
        print(f"  {enhancement.capitalize()}: {status}")
    
    total_success = sum(results.values())
    print(f"\n🎯 Overall: {total_success}/3 enhancements completed successfully")
    
    return results

def main():
    """Main entry point"""
    if len(sys.argv) > 1:
        command = sys.argv[1].lower()
        
        if command == "backup":
            run_daily_backup()
        elif command == "analytics":
            run_memory_analytics()
        elif command == "index":
            run_conversation_indexing()
        elif command == "all":
            run_all_enhancements()
        else:
            print("Usage: alice_memory_manager.py [backup|analytics|index|all]")
            sys.exit(1)
    else:
        # Default: run all enhancements
        run_all_enhancements()

if __name__ == "__main__":
    main()
