# IDEAS

## Active
- 

## Parked
- 

Notes:
- Move ideas between sections instead of deleting to preserve trace.
