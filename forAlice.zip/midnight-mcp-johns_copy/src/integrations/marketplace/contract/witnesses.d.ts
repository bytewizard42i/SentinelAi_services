export type MarketplaceRegistryPrivateState = {};
export declare const witnesses: {};
