export const NetworkId = { TestNet: 'TestNet', MainNet: 'MainNet', Undeployed: 'Undeployed' } as const;
export const setNetworkId = jest.fn();
export const getZswapNetworkId = jest.fn(); 